#virtualenv env
#source env/bin/activate
#pip3 install django
#django-admin startproject dj
#ls src
#cd src
#python manage.py migrate
#python manage.py runserver
#start an app 9:25 https://www.youtube.com/watch?v=IMG4r03G6g8
#ssh -i "qahub.pem" ec2-user@ec2-100-26-97-163.compute-1.amazonaws.com
#write basic django app on server

#https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#ConnectToInstance:instanceId=i-010dcdbff402e412b

